import 'package:flutter/material.dart';
import 'package:quizapp/quiz.dart';

void main() {
  runApp(
    const Quiz()
  );
}
